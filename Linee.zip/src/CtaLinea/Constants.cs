﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CtaLinea
{
    internal class Constants
    {
        // configuration
        internal const string Config_CtaLineaApi = "CtaLineaApi";
        internal const string Config_Oidc = "oidc";


        // scopes
        internal const string Scope_App = "app";
        internal const string Scope_Http_Api = "api";

        // headers del response
        internal const string ResponseHeader_TotalRows = "X-Total-Count";

        // endpoints
        internal const string Endpoint_Associates = "/api/associates";
        internal const string Endpoint_Cars = "/api/cars";
        internal const string Endpoint_Drivers = "/api/drivers";

        internal const string Endpoint_TT_Import = "/api/utility/ttservices";
    }
}
