﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text;
using System.Threading.Tasks;

namespace CtaLinea.Application.Utility
{
    public class QueryUtilityService 
        : IQueryUtilityService
    {
        private const string Args_FullText = "ft";
        private const string Args_Filter = "f";
        private const string Args_Order = "s";
        private const string Args_PRojection = "p";
        private const string Args_Count = "count";
        private const string Args_Page = "page";
        private const string Args_PageSize = "pagesize";

        private const string Args_Equal = "=";
        private const string Args_Separator = "&";

        private readonly CtaLineaApiConfiguration _config;
        private readonly HttpClient _http;

        public QueryUtilityService(
            HttpClient http,
            CtaLineaApiConfiguration config
            )
        {
            this._http = http;
            this._config = config;
        }

        public HttpClient Http => this._http;
        public string GetCompleteUrl(string endpoint)
        {
            return this._config.BaseAddress + endpoint;
        }

        public async Task<QueryResult<TResul>> GetListAsync<TResul> (
            QueryDefinition queryDef
            )
        {
            int totalRows = -1;

            try
            {
                string queryString = this.GetQueryString(
                    queryDef.FullText,
                    queryDef.Filter,
                    queryDef.Sort,
                    string.Empty,
                    queryDef.Page,
                    queryDef.PageSize,
                    queryDef.Count
                    );
                if (string.IsNullOrEmpty(queryString) == false)
                {
                    queryString = "?" + queryString;
                }
                // esegue la chiamata vera e propria all'endpoint
                var response = await this._http.GetAsync(
                    this._config.BaseAddress + queryDef.EndPoint + queryString);

                if (response.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    var items = await response.Content.ReadFromJsonAsync<TResul[]>();

                    totalRows = response.Headers.ParseInt(Constants.ResponseHeader_TotalRows);

                    // se tutto OK
                    return new QueryResult<TResul>(items, totalRows, queryDef.Page);
                }
                return null;
            }
            catch (Exception exc)
            {
                Console.WriteLine("erroracccio: " + exc.Message);
                return null;
            }
        }

        private string GetQueryString(
            string fullText,
            string filter,
            string sort,
            string projection,
            int page,
            int pageSize,
            bool returnCount
            )
        {
            var sb = new StringBuilder(1024);
            if (pageSize == 0) pageSize = this._config.DefaultPageSize;
            if (pageSize < 0) pageSize = int.MaxValue;

            this.AddArgument(sb, Args_FullText, fullText);
            this.AddArgument(sb, Args_Filter, filter);
            this.AddArgument(sb, Args_Order, sort);
            this.AddArgument(sb, Args_PRojection, projection);

            if (page > 0)
            {
                this.AddArgument(sb, Args_Page, page.ToString());
            }
            this.AddArgument(sb, Args_PageSize, pageSize.ToString());

            if (returnCount == true)
            {
                this.AddArgument(sb, Args_Count, true.ToString());
            }

            return sb.ToString();
        }

        public string GetPRojection<TResource, TResult>()
        {
            var baseType = typeof(TResource);
            var prjType = typeof(TResult);
            if (baseType == prjType) return null;
            var sb = new StringBuilder(1024);
            foreach (var p in prjType.GetProperties())
            {
                if (sb.Length > 0) sb.Append(",");
                sb.Append(p.Name);
            }

            return sb.ToString();
        }

        private StringBuilder AddArgument(
            StringBuilder sb,
            string argName,
            string argValue)
        {
            if (string.IsNullOrWhiteSpace(argValue) == false)
            {
                argValue = argValue.Trim();
                if (sb.Length > 0) sb.Append(Args_Separator);
                sb.Append(argName);
                sb.Append(Args_Equal);
                sb.Append(argValue);
            }
            return sb;
        }
    }

    internal static class HttpResponse_HeadersExtensions
    {
        internal static int ParseInt(
            this HttpResponseHeaders headers, 
            string key)
        {
            string value = headers?.GetValues(key)
                ?.FirstOrDefault();

            if (string.IsNullOrEmpty(value)) return 0;

            int.TryParse(value, out var number);
            return number;
        }
    }
}
