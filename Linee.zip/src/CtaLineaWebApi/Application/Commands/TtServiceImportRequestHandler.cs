﻿using MediatR;
using Microsoft.Extensions.Logging;
using NPOI.HSSF.UserModel;
using NPOI.SS.UserModel;
using NPOI.XSSF.UserModel;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using ZzSoft.CtaLinea.Dal.Repositories;
using ZzSoft.CtaLinea.Dal.Model;
using CtaLineaWebApi.Application.Utility;
using CtaLineaWebApi.Utility.BackGround;
using Microsoft.Extensions.DependencyInjection;

namespace CtaLineaWebApi.Application.Commands
{
    public class TtServiceImportRequestHandler
        : IRequestHandler<TtServiceImportRequest, bool>
    {
        private const int Delta_Minutes = 1;

        private readonly ILogger _logger;
        private readonly ITtServiceRepository _importRepo;

        private readonly IBackgroundTaskQueue _queue;
        private readonly IServiceScopeFactory _serviceScopeFactory;

        public TtServiceImportRequestHandler (
            ITtServiceRepository importRepo,
            ILogger<TtServiceImportRequestHandler> logger,
            IBackgroundTaskQueue queue,
            IServiceScopeFactory serviceScopeFactory)
        {
            this._importRepo = importRepo;
            this._logger = logger;

            this._queue = queue;
            this._serviceScopeFactory = serviceScopeFactory;
        }

        public async Task<bool> Handle(
            TtServiceImportRequest request, 
            CancellationToken cancellationToken)
        {
            this._queue.QueueBackgroundWorkItem(async token =>
            {
                using (var scope = this._serviceScopeFactory.CreateScope())
                {
                    var scopedServices = scope.ServiceProvider;
                    int j = 1000;
                    for (int i = 0; i < j; i++)
                    {
                        Console.WriteLine(i);
                    }
                    await Task.Delay(TimeSpan.FromSeconds(10), token);
                    string s = string.Empty;
                }
            });

            bool result = false;

            /*
            // controla se sia possibile o meno eseguire l'importazione
            bool canProcede = await this._importRepo.CanImportAsync(Constants.ImportDescr_TT);
            bool result = false;

            if (canProcede == true
                && request.File.Length > 0)
            {
                await this.BackGroundPorcessing(request);

                // non aspetta la fine dell'esecuzione e ritorna
                result = true;
            }
            */

            return await Task.FromResult(result)
                .ConfigureAwait(false);
        }

        private async Task BackGroundPorcessing(
            TtServiceImportRequest request)
        {
            var context = await this._importRepo.StartImportAsync(
                Constants.ImportDescr_TT,
                request.User
                );

            try
            {
                string sFileExtension = Path.GetExtension(request.File.FileName).ToLower();
                ISheet sheet = null;

                using (var stream = request.File.OpenReadStream())
                {
                    if (sFileExtension == ".xls")
                    {
                        //This will read the Excel 97-2000 formats  
                        var hssfwb = new HSSFWorkbook(stream);
                        //get first sheet from workbook  
                        sheet = hssfwb.GetSheetAt(0);
                    }
                    else if (sFileExtension == ".xlsx")
                    {
                        //This will read 2007 Excel format  
                        var hssfwb = new XSSFWorkbook(stream);
                        //get first sheet from workbook   
                        sheet = hssfwb.GetSheetAt(0);
                    }
                }
                if (sheet == null)
                {
                    this._logger.LogWarning("Importazione del file TT non è stata avviata, il file {file} non è un file Excel valido", request.File.FileName);
                    
                    context.Note = string.Format("il file {0} non è un file Excel valido", request.File.FileName);
                    // indica che limportazione è stata abortita
                    await this._importRepo.ImportAbortedAsync(context);
                    return;
                }

                // fai il lavoor  sporco
                await this.ProcessRowsAsync(context, sheet);

                // completa il lavoro di importazione
                await this._importRepo.ImportCopleteAsync(context);

            }
            catch (Exception exc)
            {
                this._logger.LogError(exc, "errpre nel caricametno del file dei servizi TT");
                if (context.Note == null) context.Note = string.Empty;
                context.Note += "\n" +  exc.Message;
                await this._importRepo.ImportFailedAsync(context);
                throw;
            }
            finally
            {
                if (context != null)
                {
                    context.Dispose();
                }
            }
        }

        private async Task ProcessRowsAsync (
            ImportContext context,
            ISheet sheet
            )
        {
            IRow headerRow = sheet.GetRow(0);

            var firstRow = sheet.FirstRowNum + 1;
            var lastRow = sheet.LastRowNum;

            // prende un punto di partenza
            var LastCheck = DateTime.Now;
            
            int serviceId = 0;
            TtService curretService = null;
            var nodes = new List<TtServiceNode>();

            foreach  (var item in this.IterateTtService (sheet, firstRow, lastRow))
            {
                // contolla se deve aggiornare los tato di progresso
                if (DateTime.Now > LastCheck.AddMinutes(Delta_Minutes))
                {
                    LastCheck = DateTime.Now;

                    // aggiorna lo stato di avanzamento del progresso
                    await this._importRepo.ReportProgressAsync(context);
                }

                if (serviceId != 0
                    &&  item.Item1.ServiceId != serviceId)
                {
                    // salva i dati e riparte
                    await this._importRepo.ImportServiceASync(
                        context,
                        curretService,
                        nodes);

                    curretService = null;
                    nodes = new List<TtServiceNode>();
                }

                curretService = item.Item1;
                nodes.Add(item.Item2);
            }
            if (curretService != null)
            {
                // salva l'ultimo servizio
                await this._importRepo.ImportServiceASync(
                    context,
                    curretService,
                    nodes);
            }

            return;
        }

        private IEnumerable<Tuple<TtService, TtServiceNode >> IterateTtService(
            ISheet sheet,
            int firstRowIndex,
            int lastRowIndex)
        {
            for (int rowIndex = firstRowIndex; rowIndex <= lastRowIndex; ++rowIndex)
            {
                var dataRow = sheet.GetRow(rowIndex);
                var service = new TtService();
                var node = new TtServiceNode();

                // popola i dati dei due elementi
                service.ServiceId = dataRow.Cells[(int) TtImportColumn.idServizio].GetIntValue().Value;
                service.LineNumber = dataRow.Cells[(int)TtImportColumn.codiceLinea].GetStringValue();
                service.RunNumber = dataRow.Cells[(int) TtImportColumn.numeroCorsa].GetStringValue();

                service.LineDescription = dataRow.Cells[(int)TtImportColumn.descrizioneLinea].GetStringValue();
                service.PathDescription = dataRow.Cells[(int)TtImportColumn.percorso].GetStringValue();
                service.Km = dataRow.Cells[(int)TtImportColumn.chilometriCapitolato].GetDecimalValue();
                
                service.FrequencyId = dataRow.Cells[(int)TtImportColumn.codiceFrequenza].GetIntValue();
                service.FrequencyDescription = dataRow.Cells[(int)TtImportColumn.descrizioneFrequenza].GetStringValue();

                service.TarifLineId = dataRow.Cells[(int)TtImportColumn.codiceLineaTariffaria].GetIntValue();
                service.TurnOneId = dataRow.Cells[(int)TtImportColumn.codiceTurno1].GetIntValue();
                service.TurnTwoId = dataRow.Cells[(int)TtImportColumn.codiceTurno2].GetIntValue();

                service.InsertDate = dataRow.Cells[(int)TtImportColumn.dataIns].GetDateTimeValue();
                service.ModifyDate = dataRow.Cells[(int)TtImportColumn.dataMod].GetDateTimeValue();
                service.LastUpdateDate = dataRow.Cells[(int)TtImportColumn.dataUltimoAggiornamentoCorsa].GetDateTimeValue();

                service.ServiceTypeId = dataRow.Cells[(int)TtImportColumn.idTipoServizio].GetIntValue();
                service.StartingLocation = dataRow.Cells[(int)TtImportColumn.localitaPartenza].GetStringValue();
                service.EndingLocation = dataRow.Cells[(int)TtImportColumn.localitaArrivo].GetStringValue();
                service.Note = dataRow.Cells[(int)TtImportColumn.note].GetStringValue();
                service.StartHour = dataRow.Cells[(int)TtImportColumn.oraPartenza].GetDateTimeValue();
                service.EndHour = dataRow.Cells[(int)TtImportColumn.oraArrivo].GetDateTimeValue();

                service.TimingDescr = dataRow.Cells[(int)TtImportColumn.descrizioneFrequenzaProspetto].GetStringValue();
                service.RequestedSittings = dataRow.Cells[(int)TtImportColumn.postiCapitolato].GetIntValue();
                service.SpecReference = dataRow.Cells[(int)TtImportColumn.riferimentoCapitolato].GetStringValue();
                service.RunType = dataRow.Cells[(int)TtImportColumn.tipoCorsa].GetStringValue();
                service.ServiceTypeDescr = dataRow.Cells[(int)TtImportColumn.tipoServizio].GetStringValue();
                service.VariantId = dataRow.Cells[(int)TtImportColumn.variante].GetIntValue();

                service.RunInHoursBook = dataRow.Cells[(int)TtImportColumn.corsaInOrario].GetBooleanValue();

                service.Company = dataRow.Cells[(int)TtImportColumn.ditta].GetStringValue();
                service.Company1 = dataRow.Cells[(int)TtImportColumn.ditta1].GetStringValue();
                service.Company2 = dataRow.Cells[(int)TtImportColumn.ditta2].GetStringValue();
                service.Company3 = dataRow.Cells[(int)TtImportColumn.ditta3].GetStringValue();
                service.DestinationTable = dataRow.Cells[(int)TtImportColumn.tabellaDestinazione].GetStringValue();

                // dati del nodo
                node.ServiceId = service.ServiceId;
                node.CollectionPointId = dataRow.Cells[(int)TtImportColumn.NODO_codNodo].GetStringValue();
                node.Description = dataRow.Cells[(int)TtImportColumn.NODO_descNodo].GetStringValue();
                node.ProgrNumber = dataRow.Cells[(int)TtImportColumn.NODO_progressivo].GetIntValue().Value;
                node.Hour = dataRow.Cells[(int)TtImportColumn.NODO_ora].GetDateTimeValue();

                DateTime? dt = dataRow.Cells[(int)TtImportColumn.NODO_sosta].GetDateTimeValue();
                if (dt != null)
                {
                    node.MinutesStop = dt.Value.Minute;
                }

                node.ArrivedAtHour = dataRow.Cells[(int)TtImportColumn.NODO_oraArrivoFermata].GetDateTimeValue();
                node.Latitude = dataRow.Cells[(int)TtImportColumn.NODO_X_nodoWGS84].GetDecimalValue();
                node.Longitude = dataRow.Cells[(int)TtImportColumn.NODO_Y_nodoWGS84].GetDecimalValue();

                var item = new Tuple<TtService, TtServiceNode>(service, node);
                yield return item;
            }
        }
    }
}
